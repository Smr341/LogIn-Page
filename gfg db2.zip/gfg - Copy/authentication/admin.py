import imp
from django.contrib import admin
from authentication.models import Add
# Register your models here.

admin.site.register(Add)