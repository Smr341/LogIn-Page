import imp
from django.contrib import admin
from authentication.models import Contact
# Register your models here.

admin.site.register(Contact)